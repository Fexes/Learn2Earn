<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'todfghjk_learn2earn');

/** MySQL database username */
define('DB_USER', 'todfghjk_learn2e');

/** MySQL database password */
define('DB_PASSWORD', 'pakistan123#@!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ';bWxi4d6>U?>,#9F3UEZao8W|^-3%a[,V $o~=:0J3J/F0es,1FIuB|*UZbd,2+S');
define('SECURE_AUTH_KEY',  '4 gjDvXQ^:Qth{h|=_&*?eQo,9|vim_ZoM]GI!bK,MLEqDa[]4hK|Pkk{9B8+XK?');
define('LOGGED_IN_KEY',    'YuxasD1JxP[s!)b:-eqjm8(hXn%>=)0<L>SX@&#qDi9$}R:[zTXB{c_5Szc:0@pf');
define('NONCE_KEY',        '}SOPXkbo[{z6UlJjaF}@-Gx.g-kzW7A$tRDiOffJcPgNRV??O/2j1YKK(;rgJs;J');
define('AUTH_SALT',        'xDcGm$GD>8z#Oi~E5lU7V;&U5F:, WiD=Sp}BUQ<5wJhyP&(E*|8%s{:qUm8P^pO');
define('SECURE_AUTH_SALT', 'PtS~_E,KGn2x$(tfVE;JP*ngh68%@%zYNiO6+kz;,}r--!w#7>3XbwjKm86U~Gn^');
define('LOGGED_IN_SALT',   'Nt$b$z}%{A@?27wZ@b$lL-9B.#B*1#V|ES`}qQiz-5j|pO@tYz#;Iq|1ttxTaFBz');
define('NONCE_SALT',       ';CoV/:q;00<I|]}3tMXNq?!Y{Es:!KRNZ,uvahXC6MKp2/q$ |!Zz/>[]#J]NM6|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
